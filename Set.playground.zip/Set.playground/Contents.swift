import UIKit

// Set : stores a unique values with no Defined order cth: followed by in instagram

// 1. First initiate
var blueFollowers: Set<String> =
    ["🎃","🤖","🤡","😎","👻"]
print(blueFollowers)

var greenFollowers: Set<String> = []

// 2. Using insert to put new value into the set
greenFollowers.insert("🎃")
greenFollowers.insert("🤖")
greenFollowers.insert("🤡")
greenFollowers.insert("👻")
greenFollowers.insert("👽") // will not overide


// 3. Use Count to get total elements inside
greenFollowers.insert("🐸")
greenFollowers.insert("😎")
print("My Followers \(blueFollowers)")
print("His Followers \(greenFollowers)")

// 4. Get the intersection of the followers
var bothWeFollow = blueFollowers.intersection(greenFollowers)

print("Both:\(bothWeFollow)")




